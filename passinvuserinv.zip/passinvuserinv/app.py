from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_session import Session
import pymysql.cursors

app = Flask(__name__)

# Secret key for session management
app.secret_key = 'your_secret_key'

# Session configuration
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Database connection parameters
db_config = {
    'host': 'mysql-1cf1d86b-undeadeyes12-d411.d.aivencloud.com',
    'user': 'avnadmin',
    'password': 'AVNS_nzZswy7rGUQc8fXsqfp',
    'db': 'defaultdb',
    'port': 28573,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    """Establishes a new database connection using db_config."""
    return pymysql.connect(**db_config)

@app.route('/')
def index():
    # Check if the user is already logged in
    if 'username' in session:
        return redirect(url_for('home'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username and password are correct by querying the database
        try:
            connection = get_db_connection()
            with connection.cursor() as cursor:
                sql_query = "SELECT * FROM users WHERE username = %s AND password = %s"
                cursor.execute(sql_query, (username, password))
                user = cursor.fetchone()
            
            if user:
                session['username'] = user['username']  # Store username in session
                flash('You were successfully logged in', 'success')
                return redirect(url_for('home'))
            else:
                flash('Invalid username or password', 'danger')
        
        except pymysql.MySQLError as e:
            flash(f"Database error: {e}", 'danger')
        
        finally:
            connection.close()
    
    return render_template('login.html')

@app.route('/home')
def home():
    # Ensure the user is logged in
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('home.html', username=session['username'])

@app.route('/logout')
def logout():
    # Remove the user from the session
    session.pop('username', None)
    flash('You were logged out', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
