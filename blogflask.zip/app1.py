from flask import Flask, render_template, request, redirect, url_for, flash, session
import pymysql
import string
import random
from flask_session import Session
import string, random


app = Flask(__name__)

# Database connection parameters
db_config = {
    'host': 'mysql-1cf1d86b-undeadeyes12-d411.d.aivencloud.com',
    'user': 'avnadmin',
    'password': 'AVNS_nzZswy7rGUQc8fXsqfp',
    'db': 'defaultdb',
    'port': 28573,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

# Secret key for session management
app.secret_key = 'your_secret_key'

# Session configuration
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

def get_db_connection():
    return pymysql.connect(**db_config)

def create_users_table():
    """Create the users table if it does not exist."""
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    email VARCHAR(50) PRIMARY KEY,
                    username VARCHAR(30) NOT NULL,
                    password VARCHAR(40) NOT NULL
                );
            """)
            cursor.execute("""
                  CREATE TABLE IF NOT EXISTS blogs (
                           id int AUTO_INCREMENT,
                           title varchar(30),
                           content varchar(400)
                );
            """)
        connection.commit()
    finally:
        connection.close()


# Call the function to create the users table
create_users_table()
@app.route('/')
def home():
    if 'username' in session:
        return render_template('home.html', username=session['username'])
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    if 'username' in session:
        username = session['username']
        
        # Fetch email from MySQL database
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT email FROM users WHERE username = %s", (username,))
            user_data = cursor.fetchone()

        if user_data:
            email = user_data['email']  # Access email by key in the dictionary
            photo_url = 'https://i.pinimg.com/736x/91/7d/f2/917df29fabeca6b6641fcc58685ccb22.jpg'  # Example photo URL
            return render_template('profile.html', username=username, email=email, photo_url=photo_url)
        else:
            return "Email not found for this user."
    
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()
        
        if user:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password!')
            return redirect(url_for('login'))
    
    return render_template('login.html')

def generate_token(length=8):
    """Generate a random token for password reset."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for i in range(length))

@app.route('/repass', methods=['GET', 'POST'])
def repass():
    if request.method == 'POST':
        email = request.form.get('email')

        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()

        if user:
            reset_token = generate_token()

            with connection.cursor() as cursor:
                cursor.execute("UPDATE users SET reset_token = %s WHERE email = %s", (reset_token, email))
                connection.commit()

            flash('Password reset instructions sent to your email.', 'success')
            return redirect(url_for('new_pass')) 
        else:
            flash('Email address not found. Please try again.', 'error')

    return render_template('forgot_pass.html')

@app.route('/new_pass', methods=['GET', 'POST'])
def new_pass():
    if request.method == 'POST':
        email = request.form.get("email")
        n1 = request.form.get("n1")
        n2 = request.form.get("n2")
        
        if n1 == n2:
            try:
                connection = get_db_connection()
                with connection.cursor() as cursor:
                    cursor.execute("UPDATE users SET password = %s WHERE email = %s", (n1, email))
                    connection.commit()
                flash('Password updated successfully. Please login with your new password.', 'success')
                return redirect(url_for('login'))
            except Exception as e:
                flash(f"An error occurred: {str(e)}", 'error')
        else:
            flash('Passwords do not match. Please try again.', 'error')

    return render_template('new_pass.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            existing_user = cursor.fetchone()
            
            if existing_user:
                flash('Username already exists!')
                return redirect(url_for('signup'))
            
            cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", (username, email, password))
            connection.commit()
            
            flash('Account created successfully! Please log in.')
            return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/add', methods=['GET', 'POST'])
def add_blog():
    if 'username' in session:
        if request.method == 'POST':
            title = request.form['title']
            content = request.form['content']
            connection = get_db_connection()
            with connection.cursor() as cursor:
                cursor.execute("INSERT INTO blogs (title, content) VALUES (%s, %s)", (title, content))
                connection.commit()
            return redirect(url_for('get_blogs'))
        return render_template('add_blog.html')
    else:
        return redirect(url_for('login'))    

@app.route('/blogs', methods=['GET'])
def get_blogs():
    if 'username' in session:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM blogs")
            rows = cursor.fetchall()
        
        blogs = [{'id': row['id'], 'title': row['title'], 'content': row['content']} for row in rows]
        return render_template('view_blogs.html', blogs=blogs)
    else:
        return redirect(url_for('login'))    

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_blog(id):
    if 'username' in session:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            if request.method == 'POST':
                title = request.form['title']
                content = request.form['content']
                cursor.execute("UPDATE blogs SET title = %s, content = %s WHERE id = %s", (title, content, id))
                connection.commit()
                return redirect(url_for('get_blogs'))

            cursor.execute("SELECT * FROM blogs WHERE id = %s", [id])
            blog = cursor.fetchone()
        return render_template('update_blog.html', blog=blog)
    else:
        return redirect(url_for('login'))

@app.route('/delete/<int:id>', methods=['GET'])
def delete_blog(id):
    if 'username' in session:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM blogs WHERE id = %s", [id])
            connection.commit()
        return redirect(url_for('get_blogs'))
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1234, debug=True)
